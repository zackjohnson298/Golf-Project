
import Player

name = input('Loading Profile for: ')
p = Player.Player(name)
p.PrintClubs()
