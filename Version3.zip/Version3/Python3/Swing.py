

class Swing():
    def __init__(self,club):
        self.club        = club # Club Parameters (Length,Loft,Lie)
        self.rawData     = []   # Raw data array from IMU
        self.Vs          = []   # Calculated sensor velocity vector array
        self.Vc          = []   # Calculated clubhead velocity vector array
        self.impactIndex = 0    # Index corresponding to detected impact
        self.clubSpeed   = 0    # Calculated clubhead speed at impact [mph]
        self.attackAngle = 0    # Calculated attack angle at impact [deg]
        self.clubPath    = 0    # Calculated path angle at impact [deg]
        self.faceToPath  = 0    # Calculated face to path angle at impact [deg]
        self.faceAngle   = 0    # Calculated face angle at impact [deg]
