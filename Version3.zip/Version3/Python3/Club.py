
class Club:
    def __init__(self,club,params):
        self.name = club
        self.length = float(params[0])
        self.loft = float(params[1])
        self.lie = float(params[2])
