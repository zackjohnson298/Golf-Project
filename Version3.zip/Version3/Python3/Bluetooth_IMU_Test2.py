import serial
import time
import matplotlib.pyplot as plt
from math import *

x = []
frequency = 1666        # Hz
measurementTime = 3     # seconds
rawDataRecieved = []    # Data packets recieved over bluetooth serial
rawData = []            # Reformatted Data Packets
pointsPerPacket = 12    # Number of data points per bluetooth packet
packetSize = 6          # Size of true data packet (3 acc + 3 gyro) = 6
inputPacketSize = 2*pointsPerPacket*packetSize + 4
sizeArray = []
c = '$'.encode('utf-8')
endList = [c,c,c,c,c];
success = '1'.encode('utf-8')
fail = '0'.encode('utf-8')
maxAttempts = 20

def PrintArray(array):
    output = []
    for ii in range(len(array)):
        output.append(array[ii])
    print(output)

ser = serial.Serial('COM8',timeout = 1)
time.sleep(1)
ser.flushInput()
input('Enter any character: ')
ser.write(b'r')
ser.flush()
numberOfRawPackets = packetSize*(frequency*measurementTime-pointsPerPacket)
start = time.time()
for ii in range(0, numberOfRawPackets, packetSize*pointsPerPacket):
    fullPacket = ser.read(inputPacketSize)
    attempts = 1
    ser.flushInput()
    while ((len(fullPacket) != inputPacketSize) and (attempts < maxAttempts)):
        ser.write(fail)
        ser.flush()
        fullPacket = ser.read(inputPacketSize)
        ser.flushInput()
        attempts = attempts + 1
    ser.write(success)
    ser.flush()
    # print(ii*6)
    # PrintArray(fullPacket)
    # if fullPacket[7] == c:
        # break
    rawDataRecieved.append(list(fullPacket))

stop = time.time()
elapsed = round(stop - start,4)
print("Elapsed Time = ",elapsed,' seconds')
for packet in rawDataRecieved:
    for ii in range(pointsPerPacket):
        index1 = ii*pointsPerPacket + 2
        index2 = index1 + 2*packetSize
        dataLine = list(packet[index1:index2])
        PrintArray(dataLine)
        rawData.append(list(dataLine))
        sizeArray.append(len(dataLine))

print("Data Points Received: ",len(rawData))
print("Average Packet Size: ",sum(sizeArray)/len(sizeArray))
ser.close()

xAcc = []
yAcc = []
zAcc = []
xGyro = []
yGyro = []
zGyro = []
# from ADAFRUIT_LSM6DS.cpp line 450
gyroFS = 2000    # For full scale = +/-2000dps
accFS = 16    # For full scale = +/-16G
# def ConvertRawData(rawData):
jj = 0
x = []
acc = [0,0,0]
gyro = [0,0,0]
for packet in rawData:
    acc[0] = (packet[0] << 8 | packet[1])*accFS/(2*16384.0)
    acc[1] = (packet[2] << 8 | packet[3])*accFS/(2*16384.0)
    acc[2] = (packet[4] << 8 | packet[5])*accFS/(2*16384.0)
    for ii in range(0,3):
        if acc[ii] > accFS:
            acc[ii] = acc[ii] - 2*accFS
    gyro[0] = (packet[6] << 8 | packet[7])*gyroFS/(2*16384.0)
    gyro[1] = (packet[8] << 8 | packet[9])*gyroFS/(2*16384.0)
    gyro[2] = (packet[4] << 8 | packet[5])*gyroFS/(2*16384.0)
    for ii in range(0,3):
        if gyro[ii] > gyroFS:
            gyro[ii] = gyro[ii] - 2*gyroFS
    xAcc.append(acc[0])
    yAcc.append(acc[1])
    zAcc.append(acc[2])
    xGyro.append(gyro[0])
    yGyro.append(gyro[1])
    zGyro.append(gyro[2])
    x.append(float(jj))
    jj = jj + 1/frequency

plt.figure()
plt.plot(x,xAcc)
plt.title('X Acceleration')
plt.figure()
plt.plot(x,yAcc)
plt.title('Y Acceleration')
plt.figure()
plt.plot(x,zAcc)
plt.title('Z Acceleration')
plt.figure()
plt.plot(x,xGyro)
plt.title('X Gyro')
plt.figure()
plt.plot(x,yGyro)
plt.title('Y Gyro')
plt.figure()
plt.plot(x,zGyro)
plt.title('Z Gyro')
plt.show()

# plt.plot(sizeArray)
# plt.show()
