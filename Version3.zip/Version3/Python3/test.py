# import matplotlib.pyplot as plt
#
# x = [0,1,2,3,4,5,6,7,8,9,10]
# plt.plot(x)
# plt.show()
from math import *
import time
points = 3*1666
pointsPerPacket = 4
packetSize = 6
outputPacketSize = 2*pointsPerPacket*packetSize + 4

arraySize = points*packetSize

ii = 0
array = []
print(arraySize)
start = time.time()
while (ii < (arraySize - pointsPerPacket*packetSize)):
    ii = ii + pointsPerPacket*packetSize
    # array.append(ii)
stop = time.time()
print("Elapsed Time = ",stop - start)
print(ii)
print(ii/packetSize)

a = list(range(0, arraySize-packetSize*pointsPerPacket, packetSize*pointsPerPacket))
print(len(a)*pointsPerPacket)
