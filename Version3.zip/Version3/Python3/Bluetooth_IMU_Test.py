import serial
import time
import matplotlib.pyplot as plt

ser = serial.Serial('COM8',timeout = 1)
time.sleep(2)
input('Enter any character: ')
ser.write(b'r')
# for ii in range(2):
#     ser.readline()

x = []
rawData = []
sizeArray = []
zeroList = [0,0,0,0,0];
for ii in range(4*1666):
    dataLine = ser.readline()
    length = len(dataLine)
    if dataLine[2:7] == zeroList:
        break
    # elif length != 16:
    #     dataLine2 = ser.readline()
    #     if len(dataLine2) + length == 16:
    #         rawData.append([list(dataLine),list(dataLine2)])
    #         sizeArray.append(16)
    #         x.append(ii)
    else:
        x.append(ii)
        rawData.append(list(dataLine))
        sizeArray.append(len(dataLine))

print("Data Points Received: ",len(rawData))
print("Average Packet Size: ",sum(sizeArray)/len(sizeArray))
ser.close()
plt.plot(x,sizeArray)
plt.show()
