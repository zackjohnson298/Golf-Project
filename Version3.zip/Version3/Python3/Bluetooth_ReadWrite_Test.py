import serial
import time
import matplotlib.pyplot as plt
import random

ser = serial.Serial('COM8')
time.sleep(1)
input('Enter any character: ')
ser.write(b'r')

for i in range(10):
    # time.sleep(.5)
    switch = random.randint(1,10)
    if switch <= 5:
        x = '0'.encode('utf-8')
    else:
        x = '1'.encode('utf-8')
    ser.write(x)
    print("Value Sent")
