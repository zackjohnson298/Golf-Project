import os
import Club

class Player:
    def __init__(self,name):
        self.name = name
        self.swings = []    # Array to store each swing
        self.clubs = []     # Array to store each club
        self.LoadProfile()

    def LoadProfile(self):
        relPath = os.path.join('Profiles',self.name)
        filePath = os.path.abspath(relPath)
        if not os.path.exists(filePath):
            userInput = input('Your Profile does not exist, would you like to create one? (y/n): ')
            while userInput.lower() != 'y' and userInput.lower() != 'n':
                userInput = input('Invalid input (y/n): ')
            if userInput.lower() == 'n':
                return
            os.makedirs(filePath)
            self.CreateClubFile()
        else:
            self.LoadClubFile()

    def CreateClubFile(self):
        relPath = os.path.join('Profiles',self.name)
        filePath = os.path.abspath(relPath)
        fullFilePath = os.path.join(filePath,'Clubs.txt')
        with open(fullFilePath,'w') as f:
            print('Creating Club Profile')
            userInput = 'y'
            while userInput.lower() != 'n':
                club = input('Enter the club type: ')
                length = input('Enter the club length [m]: ')
                loft = input('Enter the loft angle [deg]: ')
                lie = input('Enter the lie angle [deg]: ')
                str = club + ': ' + length + ', ' + loft + ', ' + lie + '\n'
                f.write(str)
                params = [length,loft,lie]
                self.clubs.append(Club.Club(club,params))
                userInput = input('Would you like to add another club? (y/n): ')
                while userInput.lower() != 'y' and userInput.lower() != 'n':
                    userInput = input('Invalid input (y/n): ')

    def LoadClubFile(self):
        relPath = os.path.join('Profiles',self.name,'Clubs.txt')
        filePath = os.path.abspath(relPath)
        if os.path.exists(filePath):
            with open(filePath,'r') as f:
                for line in f:
                    (club,vals) = line.split(': ')
                    params = vals.split(', ')
                    self.clubs.append(Club.Club(club,params))
        else:
            userInput = input('Your Club Profile does not exist, would you like to create one? (y/n): ')
            while userInput.lower() != 'y' and userInput.lower() != 'n':
                userInput = input('Invalid input (y/n): ')
            if userInput.lower() == 'y':
                self.CreateClubFile()

    def PrintClubs(self):
        for club in self.clubs:
            print(club.name,club.length,club.loft,club.lie)
