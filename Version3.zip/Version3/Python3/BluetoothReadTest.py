import serial
import time

ser = serial.Serial('COM8',timeout = 1)
time.sleep(2)
input('Enter any character: ')
ser.write(b'r')
# for ii in range(2):
#     ser.readline()

rawData = []
sizeArray = []

for ii in range(20000):
    dataLine = ser.readline()
    if dataLine[4] == 0:
        break
    else:
        rawData.append(list(dataLine))
        sizeArray.append(len(dataLine))

print("Data Points Received: ",len(rawData))
print("Average Packet Size: ",sum(sizeArray)/len(sizeArray))
ser.close()
