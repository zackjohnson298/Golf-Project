from Sensor import Sensor
import matplotlib.pyplot as plt
from VectorMath import *

sensor = Sensor()
sensor.GetSensorBytes()
sensor.ConvertRawData()
sensor.OffsetGyroBias()
sensor.SensorToBody()
sensor.DefineWorldFrame()
sensor.GetOrientation()
# sensor.BodyToWorld()
# sensor.GetVelocity()

t = []
q0_S = []
q0_C = []
q1_S = []
q1_C = []
q2_S = []
q2_C = []
q3_S = []
q3_C = []

plt.figure()
plt.suptitle('Quaternion vs. Time')

for ii in range(0,len(sensor.quat)):
    qs = Quat2List(sensor.quat[ii])
    q0_S.append(qs[0])
    q1_S.append(qs[1])
    q2_S.append(qs[2])
    q3_S.append(qs[3])
    t.append(ii/1800)

plt.subplot(4,1,1)
plt.plot(t,q0_S)
plt.subplot(4,1,2)
plt.plot(t,q1_S)
plt.subplot(4,1,3)
plt.plot(t,q2_S)
plt.subplot(4,1,4)
plt.plot(t,q3_S)

plt.show()
