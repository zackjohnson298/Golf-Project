from Swing import Swing
from Club import Club
from GolfBag import GolfBag
from Session import Session
from GPF_Constants import *
import matplotlib.pyplot as plt
from VectorMath import *
from Profile import *
import os

name = input('Load Profile for: ')
user = Profile(name)
user.Initialize()

# player = 'Lewis'
# userPath = os.path.abspath(os.path.join('Profiles',player))
# sessionsPath = os.path.join(userPath,'Sessions')
# golfBagPath = os.path.join(userPath,'GolfBag')
#
# golfBag = GolfBag()
# golfBag.LoadBag(golfBagPath)
#
# session = Session()
# session.Resume(sessionsPath,'25_07_2020_16-11-23')
# session.Begin(golfBag.clubs)

# clubs = os.listdir(golfBagPath)
# bag = GolfBag()
# bag.CreateBag()
# bag.SaveBag(golfBagPath)



# club = Club('3wood',43,15,60)
# filepath = 'Profiles/Zack/GolfBag/' + club.type + '.txt'
# club.Save(filepath)
