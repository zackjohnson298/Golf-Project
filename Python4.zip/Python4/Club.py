import os

class Club():
    def __init__(self,type,length,loft,lie,stiffness = 0):
        self.type = type
        self.length = length    #convert to meters
        self.loft = loft
        self.lie = lie
        # self.stiffness = stiffness

    def Save(self,golfBagPath):
        filepath = os.path.join(golfBagPath,self.type + '.txt')
        with open(filepath,'w+') as f:
            f.write(self.type)
            f.write('\n')
            f.write(str(self.length))
            f.write('\n')
            f.write(str(self.loft))
            f.write('\n')
            f.write(str(self.lie))
