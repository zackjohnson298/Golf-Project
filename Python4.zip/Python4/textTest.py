from Swing import Swing
from Club import Club

# for ii in range(3):
#     newClub = Club('7iron',1,20,30,5)
#     newSwing = Swing(newClub)
#     filename = 'Swings/' + str(ii+1) + '_(' + newClub.type + ').txt'
#     newSwing.Save(filename)
newClub = Club('7iron',1,20,30,5)
newSwing = Swing(newClub)
filename = 'Swings/2_(7iron).txt'
newSwing.Load(filename)
