from Sensor import Sensor
from VectorMath import *
from math import *

class Swing():
    def __init__(self):


    def Get(self):
