from Swing import *
import os
from datetime import date
from GPF_Constants import *
import matplotlib.pyplot as plt

class Session():
    def __init__(self):
        self.filepath = ''

    def Create(self,basePath):
        today = date.today()
        dateSTR = today.strftime("%d_%m_%Y")
        datePath = os.path.join(basePath,dateSTR)
        if os.path.exists(datePath):
            numberOfSessionsToday = len(os.listdir(datePath)) + 1
            newSessionPath = os.path.join(datePath,'Session_' + str(numberOfSessionsToday))
        else:
            newSessionPath = os.path.join(datePath,'Session_1')
        os.makedirs(newSessionPath)
        self.filepath = newSessionPath

    #Error check
    def Resume(self,basePath):
        date = input('Enter the date of desired Session (DD_MM_YYYY): ')
        sessionNumber = input('Enter desired Session Number: ')
        datePath = os.path.join(basePath,date)
        self.filepath = os.path.join(datePath,'Session_' + sessionNumber)
        return os.path.exists(self.filepath)

    def Begin(self,clubs):
        clubChoice = input('Enter your current club: ')
        while not (clubChoice in clubs):
            print('Desired club choice is unavailable, try again.')
            clubChoice = input('Enter your current club: ')
        club = clubs[clubChoice]

        numberOfSwings = len(os.listdir(self.filepath))
        while 1:
            print('Choose an option:')
            print('  n = record new swing')
            print('  c = change club (current = ' + club.type + ')')
            print('  e = end session')

            userInput = input('Input: ')
            if userInput == 'c':
                clubChoice = input('Enter your current club: ')
                while not (clubChoice in clubs):
                    print('Desired club choice is unavailable, try again.')
                    clubChoice = input('Enter your current club: ')
                club = clubs[clubChoice]
                continue
            elif userInput == 'n':
                newSwing = Swing(club)
                newSwing.GetSensorData()
            elif userInput == 'e':
                choice = input('Are you sure you want to end this session?(y/n): ')
                if choice == 'y':
                    break
                continue
            else:
                print('Invalid input')
                continue

            # Change for user output
            t = [0]
            for ii in range(1,len(newSwing.sensor.gyroMag)):
                t.append(t[ii-1] + 1/FREQUENCY)
            plt.plot(t,newSwing.sensor.gyroMag)
            plt.xlabel('Time t [s]')
            plt.ylabel('Gyro Magnitude [rad/s]')
            plt.show()

            userInput = input('Would you like to save this swing?(y/n): ')
            if userInput == 'y':
                numberOfSwings += 1
                filename = str(numberOfSwings) + '_(' + club.type + ').txt'
                newSwingPath = os.path.join(self.filepath, filename)
                newSwing.Save(newSwingPath)
