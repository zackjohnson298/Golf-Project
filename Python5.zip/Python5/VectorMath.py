from math import *
import numpy as np

class Quaternion():
    def __init__(self, q0 = 1, q1 = 0, q2 = 0, q3 = 0):
        self.q0 = q0
        self.q1 = q1
        self.q2 = q2
        self.q3 = q3

    def Normalize(self):
        q0 = self.q0
        q1 = self.q1
        q2 = self.q2
        q3 = self.q3
        mag = sqrt(q0**2 + q1**2 + q2**2 + q3**2)
        self.q0 = q0 / mag
        self.q1 = q1 / mag
        self.q2 = q2 / mag
        self.q3 = q3 / mag

    def Print(self):
        print(str(self.q0) + ' ' + str(self.q1) + ' ' + str(self.q2) + ' ' + str(self.q3))

class Vector():
    def __init__(self, x = 0, y = 0, z = 0):
        self.x = x
        self.y = y
        self.z = z

    def Normalize(self):
        mag = Norm(self)
        self.x /= mag
        self.y /= mag
        self.z /= mag

    def Copy(self):
        return ScaleVector(self,1)

    def Print(self):
        print(str(self.x) + ' ' + str(self.y) + ' ' + str(self.z))


def Cross(a,b):
    ax = a.x
    ay = a.y
    az = a.z
    bx = b.x
    by = b.y
    bz = b.z
    cx = ay*bz - az*by
    cy = az*bx - ax*bz
    cz = ax*by - ay*bx
    c = Vector(cx,cy,cz)
    return c

def Norm(v):
    x = v.x
    y = v.y
    z = v.z
    mag = sqrt(x**2 + y**2 + z**2)
    return mag

def Dot(a,b):
    return (a.x*b.x + a.y*b.y + a.z*b.z)

def VectorSubtract(a,b):
    bMinus = ScaleVector(b,-1)
    c = VectorAdd(a,bMinus)
    return c

def VectorAdd(a,b):
    cx = a.x + b.x
    cy = a.y + b.y
    cz = a.z + b.z
    c = Vector(cx,cy,cz)
    return c

def QuatProd(a,b):
    # a and b are Quaternion objects
    a0 = a.q0
    a1 = a.q1
    a2 = a.q2
    a3 = a.q3

    b0 = b.q0
    b1 = b.q1
    b2 = b.q2
    b3 = b.q3

    c0 = a0*b0 - a1*b1 - a2*b2 - a3*b3
    c1 = a0*b1 + a1*b0 + a2*b3 - a3*b2
    c2 = a0*b2 - a1*b3 + a2*b0 + a3*b1
    c3 = a0*b3 + a1*b2 - a2*b1 + a3*b0

    c = Quaternion(c0,c1,c2,c3)
    return c

def QuatConj(q):
    q0 = q.q0
    q1 = q.q1
    q2 = q.q2
    q3 = q.q3
    qConj = Quaternion(q0,-q1,-q2,-q3)
    return qConj

def Vec2Quat(v):
    x = v.x
    y = v.y
    z = v.z
    q = Quaternion(0,x,y,z)
    return q

def Quat2Vec(q):
    q1 = q.q1
    q2 = q.q2
    q3 = q.q3
    v = Vector(q1,q2,q3)
    return v

def ScaleQuat(q,k):
    q0 = k*q.q0
    q1 = k*q.q1
    q2 = k*q.q2
    q3 = k*q.q3
    return Quaternion(q0,q1,q2,q3)

def ScaleVector(v,k):
    x = k*v.x
    y = k*v.y
    z = k*v.z
    return Vector(x,y,z)

def QuatRot(q,v):
    qv = Vec2Quat(v)
    qConj = QuatConj(q)
    vRot = Quat2Vec(QuatProd(QuatProd(q,qv),qConj))
    return vRot

def Quat2List(q):
    q0 = q.q0
    q1 = q.q1
    q2 = q.q2
    q3 = q.q3
    qList = list([q0,q1,q2,q3])
    return qList

def Vec2List(v):
    x = v.x
    y = v.y
    z = v.z
    vList = list([x,y,z])
    return vList

def AngularVelocity2Quat(w,dt):
    # w is Vector type
    wx = w.x
    wy = w.y
    wz = w.z
    wMag = sqrt(wx**2 + wy**2 + wz**2)
    if wMag == 0:
        q = Quaternion()
    else:
        half_dt_wMag = 0.5*dt*wMag
        q0 = cos(half_dt_wMag)
        q1 = sin(half_dt_wMag) * wx / wMag
        q2 = sin(half_dt_wMag) * wy / wMag
        q3 = sin(half_dt_wMag) * wz / wMag
        q = Quaternion(q0,q1,q2,q3)
    return q
