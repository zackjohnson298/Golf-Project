from Club import Club
import os

class GolfBag():
    def __init__(self):
        self.clubs = {}

    #LoadBag() takes club data from a saved filepath and initializes a GolfBag object
    def LoadBag(self,golfBagPath):
        clubs = os.listdir(golfBagPath)
        # This would print all the files and directories
        for club in clubs:
            filepath = os.path.join(golfBagPath,club)
            with open(filepath,'r') as f:
                clubType = f.readline()[:-1]
                length = float(f.readline())
                loft = float(f.readline())
                lie = float(f.readline())
                newClub = Club(clubType,length,loft,lie)
                self.clubs[clubType] = newClub

    #ModifyBag() allows user to change the contents of their bag
    def ModifyBag(self,golfBagPath):
        print('Modifying Golf Bag')
        userInput = 'y'
        while userInput == 'y':
            clubType = input('Which club would you like to change/add?: ')
            length = input('Enter the length (in.): ')
            loft = input('Enter the loft (deg): ')
            lie = input('Enter the lie (deg): ')
            newClub = Club(clubType,length,loft,lie)
            self.clubs[clubType] = newClub
            userInput = input('Would you like to add another club? (y/n): ')
        self.SaveBag(golfBagPath)

    #SaveBag() takes the current GolfBag and saves each club given filepath
    def SaveBag(self,golfBagPath):
        for club in self.clubs:
            self.clubs[club].Save(golfBagPath)

    #CreateBag() creates a new Golf bag for a profile, has the option for a
    #default bag
    def CreateBag(self):
        userInput = input('Would you like to create a custom bag?(y/n): ')
        if userInput == 'y':
            while userInput == 'y':
                clubType = input('Enter the club type: ')
                length = input('Enter the length (in.): ')
                loft = input('Enter the loft (deg): ')
                lie = input('Enter the lie (deg): ')
                newClub = Club(clubType,length,loft,lie)
                self.clubs[newClub] = newClub
                userInput = input('Would you like to add another club?(y/n): ')
        else:
            self.clubs = {
                'Driver': Club('Driver',45,10.5,60),
                '3wood': Club('3wood',43,15,60),
                '4wood': Club('4wood',42.5,16,60),
                '5wood': Club('5wood',42,17.5,60),
                ''
                '3iron': Club('3iron',39,21,60.5),
                '4iron': Club('4iron',38.5,24,61),
                '5iron': Club('5iron',38,27,61.5),
                '6iron': Club('6iron',37.5,30,62),
                '7iron': Club('7iron',37,34,62.5),
                '8iron': Club('8iron',36.5,38,63),
                '9iron': Club('9iron',36,42,63.5),
                'PW': Club('PW',35.5,46,64),
                'GW': Club('GW',35.25,50,64.5),
                'SW': Club('SW',35,54,65),
                'LW': Club('LW',34.75,58,65.5)}
