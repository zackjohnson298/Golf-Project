from Sensor import Sensor
from VectorMath import *
from GPF_Constants import *
from math import *

class Swing():
    def __init__(self,club):
        self.impactIndex = 0
        self.impactEndIndex = 0
        self.clubheadVel = []
        self.clubheadSpeed = []
        self.faceToPath = []
        self.attackAngle = []
        self.faceAngle = []
        self.clubPath = []
        self.club = club
        self.sensor = Sensor()
        self.trueParams = []

    #GetSensorData() calls all of the necessary Sensor methods to get sensor
    #gyro, acceleration, and velocity values
    def GetSensorData(self):
        self.sensor.GetSensorBytes()
        self.sensor.ConvertRawData()
        self.sensor.OffsetGyroBias()
        self.sensor.FilterRawData()     #Modified 8-9-2020
        self.sensor.SensorToBody()
        self.sensor.DefineWorldFrame()
        self.sensor.GetOrientation()
        self.sensor.BodyToWorld()
        self.sensor.GetVelocity()

    #GetClubheadSpeed() calculates the clubhead speed given the length of the
    #club and sensor velocity in the world frame (See Eqn. ...)
    def GetClubSpeed(self):
        Vc = []
        club = Quaternion(0,0,0,-self.club.length)
        for ii in range(0,len(self.sensor.accWorld)):
            q = self.sensor.quat[ii]
            vS = self.sensor.velWorld[ii]
            w = Vec2Quat(self.sensor.gyro[ii])
            qdot = ScaleQuat(QuatProd(q,w),.5)
            v1 = Quat2Vec(QuatProd(QuatProd(qdot,club),QuatConj(q)))
            v2 = Quat2Vec(QuatProd(QuatProd(q,club),QuatConj(qdot)))
            vC = VectorAdd(VectorAdd(vS,v1),v2)
            vC = ScaleVector(vC,2.23694)    #m/s to mph
            self.clubheadVel.append(vC)
            self.clubheadSpeed.append(Norm(vC))

    #DetectImpact() takes data and determines the index corresponding to impactIndex
    #Currently finds maximum clubhead speed, but will be optimized
    def DetectImpact(self):
        maxClubheadSpeed = 0
        for ii in range(0,len(self.sensor.acc)):
            if self.clubheadSpeed[ii] > maxClubheadSpeed:
                self.impactIndex = ii
                maxClubheadSpeed = self.clubheadSpeed[ii]

    #DetectImpact2 finds the spike in sensor data that corresponds to impact
    #based on the the first time derivative or raw accelermoter data
    def DetectImpact2(self):
        cutoff = 10000
        rawAccMag = self.sensor.rawAccMag
        for ii in range(1,len(rawAccMag)):
            d_dt_rawAcc = abs(rawAccMag[ii] - rawAccMag[ii-1])*FREQUENCY
            if d_dt_rawAcc >= cutoff:
                self.impactIndex = ii
                break


    #GetAttackAngle() calculates the attack angle given an index of impact
    #(See Eqn. ...)
    def GetAttackAngle(self):
        velVec = self.clubheadVel[self.impactIndex]
        zVec = Vector(0,0,1)
        self.attackAngle = -(RAD2DEG*acos(Dot(velVec,zVec)/Norm(velVec)) - 90)

    #GetClubPath() calculates the club path angle given an index of impact
    #(See Eqn. ...)
    def GetClubPath(self):
        velVec = self.clubheadVel[self.impactIndex]
        velVecxy = Vector(velVec.x,velVec.y,0)
        velVecxy.Normalize()
        yVec = Vector(0,1,0)
        if velVecxy.x >= 0:
            self.clubPath = RAD2DEG*acos(Dot(velVecxy,yVec))
        else:
            self.clubPath = -RAD2DEG*acos(Dot(velVecxy,yVec))

    #GetFaceAngle() calculates the face angle given an index of impact
    #(See Eqn. ...)
    def GetFaceAngle(self):
        q = self.sensor.quat[self.impactIndex]
        yS = Vector(0,1,0)
        faceVec = QuatRot(QuatConj(q),yS)
        faceVecxy = Vector(faceVec.x,faceVec.y,0)
        faceVecxy.Normalize()
        yVec = Vector(0,1,0)
        if faceVecxy.x >= 0:
            self.faceAngle = RAD2DEG*acos(Dot(faceVecxy,yVec))
        else:
            self.faceAngle = -RAD2DEG*acos(Dot(faceVecxy,yVec))

    #GetFaceToPath() calculates the club path angle given face angle and
    #club path angle (See Eqn. ...)
    def GetFaceToPath(self):
        self.faceToPath = self.faceAngle - self.clubPath

    #Load() reads the saved data from filename, then performs the same
    #function as GetSensorData()
    def Load(self,filename):
        with open(filename,'r') as f:
            paramsStr = f.readline()
            dataStr = ''
            params = []
            for c in paramsStr:
                if (c == ' ') or (c == '\n'):
                    params.append(float(dataStr))
                    dataStr = ''
                else:
                    dataStr = dataStr + c

            rawData = []
            for line in f:
                dataStr = ''
                dataLine = []
                for c in line:
                    if c == ' ':
                        dataLine.append(float(dataStr))
                        dataStr = ''
                    else:
                        dataStr = dataStr + c
                rawData.append(list(dataLine))

        self.trueParams = params
        accList = [0,0,0]
        gyroList = [0,0,0]
        for ii in range(len(rawData)):
            accList = rawData[ii][0:3]
            gyroList = rawData[ii][3:6]
            self.sensor.rawAcc.append(Vector(accList[0],accList[1],accList[2]))
            self.sensor.rawGyro.append(Vector(gyroList[0],gyroList[1],gyroList[2]))
            self.sensor.rawAccMag.append(Norm(self.sensor.rawAcc[ii]))
            self.sensor.rawGyroMag.append(Norm(self.sensor.rawGyro[ii]))

        self.sensor.FilterRawData()
        self.sensor.OffsetGyroBias()
        self.sensor.DefineWorldFrame()
        self.sensor.GetOrientation()
        self.sensor.BodyToWorld()
        return self.sensor.GetVelocity()


    #Save() writes the raw data from the sensor to a text file
    #specified by filename
    def Save(self,filename):
        data = []
        for ii in range(len(self.sensor.acc)):
            dataLine = []
            accList = Vec2List(self.sensor.acc[ii])
            gyroList = Vec2List(self.sensor.gyro[ii])
            dataLine = list(accList + gyroList)
            data.append(dataLine)
        clubheadSpeed = input('Enter clubhead speed: ')
        attackAngle = input('Enter Attack Angle: ')
        faceToPath = input('Enter Face to Path: ')
        clubPath = input('Enter Club Path: ')
        faceAngle = input('Enter Face Angle: ')

        with open(filename,'w+') as f:
            f.write(clubheadSpeed + ' ')
            f.write(attackAngle + ' ')
            f.write(faceToPath + ' ')
            f.write(clubPath + ' ')
            f.write(faceAngle + '\n')
            for ii in range(len(data)):
                for jj in range(len(data[ii])):
                    f.write(str(data[ii][jj]) + ' ')
                f.write('\n')
