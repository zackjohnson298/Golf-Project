from Profile import *

# Login page
name = input('Load Profile for: ')
user = Profile(name)
user.Initialize()

# Main Menu
# display options
# start new session
# load old session
# Modify clubs/profile
# Swing analysis
while 1:
    print('Main Menu')
    print('Please select an option:')
    print('  ns - Create New Range Session')
    print('  cs - Load/Continue Saved Range Session')
    print('  mb - Modify Golf Bag')
    print('  e  - Exit')
    userInput = input('Input: ')

    if userInput == 'ns':
        print('Starting new Session')
        user.BeginNewSession()

    elif userInput == 'cs':
        print('Loading saved Session')
        user.LoadSavedSession()

    elif userInput == 'mb':
        user.golfBag.ModifyBag(user.golfBagPath)

    elif userInput == 'e':
        choice = input('Are you sure you want to exit? (y/n): ')
        while (choice != 'y' and choice != 'n'):
            choice = input('Invalid input, would you like to exit?: ')
        if choice == 'n':
            continue
        else:
            break

    else:
        print('Invalid input')

print('Goodbye')
