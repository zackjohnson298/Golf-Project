from VectorMath import *
from GPF_Constants import *
from GPF_Functions import *
from math import *
import serial
import time
from scipy.fft import fft, ifft
from scipy.signal import butter, lfilter, filtfilt
import numpy as np

#-----------------------------------------------------------------------------#
#The Sensor Class included all the methods related to the sensor object. This
#should include retrieving the sensor data through bluetooth, processing the
#data, and rotating sensor data into the world frame for further analysis down
#stream.
#-----------------------------------------------------------------------------#

# Add GetGyroBias()

class Sensor():
    def __init__(self):
        self.rawSensorBytes = []
        self.rawAcc = []
        self.acc = []
        self.accWorld = []
        self.rawGyro = []
        self.gyro = []
        self.gyroWorld = []
        self.rawAccMag = []
        self.rawGyroMag = []
        self.accMag = []
        self.gyroMag = []
        self.velWorld = []
        self.quat = []


    #GetSensorBytes() is responsible for opening the bluetooth serial port and
    #requesting packet package. It is also includes error correction to ensure
    #no data packet is missing.
    def GetSensorBytes(self,waitForInput = False):
        ser = serial.Serial('COM8')
        time.sleep(.1)
        ser.flushInput()
        if waitForInput:
            input('Enter any character: ') #Comment out later
        ser.write(b'r')
        ser.flush()
        rawDataRecieved = []    # Data packets recieved over bluetooth serial
        maxAttempts = 20
        fail = '0'.encode('utf-8')
        success = '1'.encode('utf-8')
        for ii in range(0, NUMBER_OF_RAW_PACKETS, PACKET_SIZE*POINTS_PER_PACKET):
            fullPacket = ser.read(INPUT_PACKET_SIZE)
            attempts = 1
            ser.flushInput()
            while ((len(fullPacket) != INPUT_PACKET_SIZE) and (attempts < maxAttempts)):
                ser.write(fail)
                ser.flush()
                fullPacket = ser.read(INPUT_PACKET_SIZE)
                ser.flushInput()
                attempts = attempts + 1
            ser.write(success)
            ser.flush()
            rawDataRecieved.append(list(fullPacket))

        # Extracts individual datapoints from packets
        for packet in rawDataRecieved:
            for ii in range(POINTS_PER_PACKET):
                index1 = ii*POINTS_PER_PACKET + 2
                index2 = index1 + 2*PACKET_SIZE
                dataLine = list(packet[index1:index2])
                self.rawSensorBytes.append(list(dataLine))
        ser.close()


    #ConvertRawData() is responsible for bit shifting and magnitude correction
    #to ensure the sensor outputs are within their full scale value.
    def ConvertRawData(self):
        jj = 0
        x = []
        acc = [0,0,0]
        gyro = [0,0,0]
        for packet in self.rawSensorBytes:
            acc[0] = (packet[0] << 8 | packet[1])*ACC_FS/(2*16384.0)
            acc[1] = (packet[2] << 8 | packet[3])*ACC_FS/(2*16384.0)
            acc[2] = (packet[4] << 8 | packet[5])*ACC_FS/(2*16384.0)
            for ii in range(0,3):
                if acc[ii] > ACC_FS:
                    acc[ii] = acc[ii] - 2*ACC_FS
            gyro[0] = DEG2RAD*(packet[6] << 8 | packet[7])*GYRO_FS/(2*16384.0)
            gyro[1] = DEG2RAD*(packet[8] << 8 | packet[9])*GYRO_FS/(2*16384.0)
            gyro[2] = DEG2RAD*(packet[10] << 8 | packet[11])*GYRO_FS/(2*16384.0)
            for ii in range(0,3):
                if gyro[ii] > DEG2RAD*GYRO_FS:
                    gyro[ii] = gyro[ii] - 2*DEG2RAD*GYRO_FS
            self.rawAcc.append(Vector(acc[0],acc[1],acc[2]))
            self.rawGyro.append(Vector(gyro[0],gyro[1],gyro[2]))
            self.rawAccMag.append(sqrt(acc[0]**2 + acc[1]**2 + acc[2]**2))
            self.rawGyroMag.append(sqrt(gyro[0]**2 + gyro[1]**2 + gyro[2]**2))


    #OffsetGyroBias() is responsible for offsetting the gyro's outputs by a
    #constant to limit drift in the quaternion later.
    def OffsetGyroBias(self):
        xOffset = -0.004449716846393372
        yOffset = 0.005117211423445101
        zOffset = -0.002953633863401881
        offset = Vector(xOffset,yOffset,zOffset)
        for ii in range(len(self.gyro)):
            newGyro = VectorSubtract(self.gyro[ii],offset)
            self.gyro[ii] = newGyro
            # self.gyroMag.append(Norm(newGyro))

    #SensorToBody() is responsible for rotating the sensor frame into the body
    #frame of the golf club. This is just in case the sensor board is aligned
    #differently from the golf club frame when mounted.
    #(Will be unnessecary when embedded system is developed)
    def SensorToBody(self):
        # Quaternion to rotate from actual sensor frame to club-fixed body frame
        qS_B = Quaternion(0.5,-0.5,0.5,-0.5)
        for ii in range(len(self.rawAcc)):
            aRawS = self.rawAcc[ii]
            gRawS = self.rawGyro[ii]
            aRawB = QuatRot(qS_B,aRawS)
            gRawB = QuatRot(qS_B,gRawS)
            self.rawAcc[ii] = aRawB
            self.rawGyro[ii] = gRawB


    def FilterRawData(self):
        rawAccX = []
        rawAccY = []
        rawAccZ = []
        rawGyroX = []
        rawGyroY = []
        rawGyroZ = []
        t = [0]
        for ii in range(len(self.rawAcc)):
            rawAccX.append(self.rawAcc[ii].x)
            rawAccY.append(self.rawAcc[ii].y)
            rawAccZ.append(self.rawAcc[ii].z)
            rawGyroX.append(self.rawGyro[ii].x)
            rawGyroY.append(self.rawGyro[ii].y)
            rawGyroZ.append(self.rawGyro[ii].z)
            t.append(t[ii] + 1/FREQUENCY)
        t.pop()

        filtAccX = ImpactNoiseCompensator(t,rawAccX,FS = ACC_FS,satComp=True)
        filtAccY = ImpactNoiseCompensator(t,rawAccY,FS = ACC_FS)
        filtAccZ = ImpactNoiseCompensator(t,rawAccZ,FS = ACC_FS)
        filtGyroX = ImpactNoiseCompensator(t,rawGyroX,FS = DEG2RAD*GYRO_FS)
        filtGyroY = ImpactNoiseCompensator(t,rawGyroY,FS = DEG2RAD*GYRO_FS)
        filtGyroZ = ImpactNoiseCompensator(t,rawGyroZ,FS = DEG2RAD*GYRO_FS)

        for ii in range(len(t)):
            acc = Vector(filtAccX[ii],filtAccY[ii],filtAccZ[ii])
            gyro = Vector(filtGyroX[ii],filtGyroY[ii],filtGyroZ[ii])
            self.acc.append(acc)
            self.gyro.append(gyro)
            self.gyroMag.append(Norm(self.gyro[ii]))
            self.accMag.append(Norm(self.acc[ii]))

    # FIX LATER!!!!!!!!!!!!!
    #DefineWorldFrame() is responsible for establishing the world frame such
    #that data can be outputted with respect to a fixed frame.
    #(See Eqn. ...)
    def DefineWorldFrame(self):
        calTime = 0.5
        rxSum = 0
        rySum = 0
        rzSum = 0
        for ii in range(int(calTime*FREQUENCY)):
            aS = self.acc[ii]
            rxSum += aS.x
            rySum += aS.y
            rzSum += aS.z
        rx = rxSum / (calTime*FREQUENCY)
        ry = rySum / (calTime*FREQUENCY)
        rz = rzSum / (calTime*FREQUENCY)
        r = Vector(rx,ry,rz)
        r.Print()
        r.Normalize()
        Y = Vector(0,1,0)
        Z = Vector(0,0,1)
        xW = Cross(Y,r)
        xW.Normalize()
        theta1 = acos(Dot(Y,r)) - pi/2
        q1_0 = cos(theta1/2)
        q1_1 = xW.x*sin(theta1/2)
        q1_2 = xW.y*sin(theta1/2)
        q1_3 = xW.z*sin(theta1/2)
        q1 = Quaternion(q1_0, q1_1, q1_2, q1_3)
        r2 = QuatRot(QuatConj(q1),r)
        theta2 = acos(Dot(Z,r2))
        q2_0 = cos(theta2/2)
        q2_1 = Y.x*sin(theta2/2)
        q2_2 = Y.y*sin(theta2/2)
        q2_3 = Y.z*sin(theta2/2)
        q2 = Quaternion(q2_0, q2_1, q2_2, q2_3)
        self.quat.append(QuatConj(QuatProd(q1,q2)))

    #GetOrientation() is responsible for getting the quaternion from the gyro
    #data.
    def GetOrientation(self):
        dt = 1 / FREQUENCY
        for ii in range(1,len(self.gyro)):
            w = self.gyro[ii-1]         #Left-hand riemann sum
            delta_q = AngularVelocity2Quat(w,dt)
            self.quat.append(QuatProd(self.quat[ii-1],delta_q))
            self.quat[ii].Normalize()

    #BodyToWorld() is responsible for rotating sensor data in the body frame to
    #the fixed world frame.
    def BodyToWorld(self):
        for ii in range(len(self.acc)):
            aB = self.acc[ii]
            gB = self.gyro[ii]
            aWorld = QuatRot(self.quat[ii],aB)
            gWorld = QuatRot(self.quat[ii],gB)
            self.accWorld.append(aWorld)
            self.gyroWorld.append(gWorld)

    #Optimize!!!
    #GetVelocity() is responsible for getting the velocity of the sensor in the
    #world frame. This will be used later for velocities of the club head.
    #(See Eqn. ...)
    def GetVelocity(self):
        stationary = []
        for wMag in self.gyroMag:
            if wMag <= GYRO_THRESH:
                stationary.append(1)
            else:
                stationary.append(0)

        xddot = []
        yddot = []
        zddot = []

        for ii in range(0,len(self.acc)):
            a = Vec2List(self.accWorld[ii])
            xddot.append(a[0])
            yddot.append(a[1])
            zddot.append(a[2])

        nonStatPeriods = []
        xdot = [0]
        ydot = [0]
        zdot = [0]
        startIndex = 0
        for ii in range(1,len(self.accWorld)):
            if stationary[ii] == 1:
                xdot.append(0)
                ydot.append(0)
                zdot.append(0)
                if stationary[ii-1] == 0:
                    nonStatPeriods.append(list([startIndex,ii-1]))
            else:
                xdot.append(GRAVITY*0.5*(xddot[ii] + xddot[ii-1])/FREQUENCY + xdot[ii-1])
                ydot.append(GRAVITY*0.5*(yddot[ii] + yddot[ii-1])/FREQUENCY + ydot[ii-1])
                zdot.append(GRAVITY*0.5*(zddot[ii] + zddot[ii-1])/FREQUENCY + zdot[ii-1])
                if stationary[ii-1] == 1:
                    startIndex = ii-1

        for i in range(0,len(nonStatPeriods)):
            i1 = nonStatPeriods[i][0]
            i2 = nonStatPeriods[i][1]
            N = i2 - i1
            dvx = xdot[i2]-xdot[i1]
            dvy = ydot[i2]-ydot[i1]
            dvz = zdot[i2]-zdot[i1]
            ratex = dvx/N
            ratey = dvy/N
            ratez = dvz/N
            for ii in range(i1,i2+1):
                xdot[ii] -= ratex*(ii - i1)
                ydot[ii] -= ratey*(ii - i1)
                zdot[ii] -= ratez*(ii - i1)

        for ii in range(0,len(self.accWorld)):
            v = Vector(xdot[ii],ydot[ii],zdot[ii])
            self.velWorld.append(v)

        return stationary
    # Modifications used during analysis
