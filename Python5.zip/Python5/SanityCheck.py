# Instead of using a low-pass filter to remove noise during impact, do the following:
#   - relatively high cutoff Low-pass filter on raw data to remove
#       sensor noise / vibrations from impact
#   - fit a curve preferrably to raw data or to velocity data

from Swing import *
from GolfBag import *
from GPF_Constants import *
from GPF_Functions import *
import matplotlib.pyplot as plt
import os
from scipy.fft import fft, ifft
from scipy.signal import butter, lfilter, filtfilt
import numpy as np

path1 = os.path.abspath('Profiles')
path2 = os.path.join(path1,'Lewis')
golfBagPath = os.path.join(path2,'GolfBag')
golfbag = GolfBag()
golfbag.LoadBag(golfBagPath)

path1 = os.path.abspath('Trackman Test 1_ 08-06-2020')
path2 = os.path.join(path1,'06_08_20')
path3 = os.path.join(path2,'Session_2')
swingFilepath = os.path.join(path3,'11_(5iron).txt')

club = golfbag.clubs['5iron']
swing = Swing(club)

swing.Load(swingFilepath)
trueClubSpeed = swing.trueParams[0]
trueAttackAngle = swing.trueParams[1]
trueFaceToPath = swing.trueParams[2]
trueClubPath = swing.trueParams[3]
trueFaceAngle = swing.trueParams[4]

swing.GetClubSpeed()
swing.DetectImpact2()
t = [0]
trueClubSpeedList = [trueClubSpeed]
# tCompare = 2.2544 #sum([2.24852,2.2518,2.2544,2.2509])/4
# indexReached = False
for ii in range(1,len(swing.clubheadSpeed)):
    t.append(t[ii-1] + 1/FREQUENCY)
    # if t[ii] >= tCompare and not indexReached:
    #     swing.impactIndex = ii
    #     indexReached = True
    trueClubSpeedList.append(trueClubSpeed)

clubSpeedX = []
clubSpeedY = []
clubSpeedZ = []
index = []
for ii in range(len(t)):
    clubSpeedX.append(swing.clubheadVel[ii].x)
    clubSpeedY.append(swing.clubheadVel[ii].y)
    clubSpeedZ.append(swing.clubheadVel[ii].z)

plt.figure()
plt.plot(list(range(len(t))),clubSpeedX)
plt.title('X Club Velocity')
plt.figure()
plt.plot(list(range(len(t))),clubSpeedY)
plt.title('Y Club Velocity')
plt.figure()
plt.plot(list(range(len(t))),clubSpeedZ)
plt.title('Z Club Velocity')


swing.GetAttackAngle()
swing.GetClubPath()
swing.GetFaceAngle()
swing.GetFaceToPath()

print(sum([2.24852,2.2518,2.2544,2.2509])/4)
print('Impact Parameters: (Actual : Calculated)')
print('Clubhead Speed: ' + str(trueClubSpeed) + ' : ' + str(swing.clubheadSpeed[swing.impactIndex]))
print('  Attack Angle: ' + str(trueAttackAngle) + ' : ' + str(swing.attackAngle))
print('     Club Path: ' + str(trueClubPath) + ' : ' + str(swing.clubPath))
print('  Face to Path: ' + str(trueFaceToPath) + ' : ' + str(swing.faceToPath))
print('    Face Angle: ' + str(trueFaceAngle) + ' : ' + str(swing.faceAngle))

# percentError = (trueClubSpeed - max(swing.clubheadSpeed))/trueClubSpeed
# print('% Error : ' + str(percentError))

impact = []
y = []
for ii in range(int(trueClubSpeed)):
    y.append(ii)
    impact.append(swing.impactIndex)

attackAngle = []
clubPath = []
faceToPath = []
faceAngle = []
trueAttackAngleList = []
trueClubPathList = []
trueFaceToPathList = []
trueFaceAngleList = []

print(swing.impactIndex)
index1 = swing.impactIndex - 20
index2 = swing.impactIndex + 20

for ii in range(index1,index2):
    swing.impactIndex = ii
    swing.GetAttackAngle()
    swing.GetClubPath()
    swing.GetFaceAngle()
    swing.GetFaceToPath()
    attackAngle.append(swing.attackAngle)
    clubPath.append(swing.clubPath)
    faceToPath.append(swing.faceToPath)
    faceAngle.append(swing.faceAngle)
    trueAttackAngleList.append(trueAttackAngle)
    trueClubPathList.append(trueClubPath)
    trueFaceToPathList.append(trueFaceToPath)
    trueFaceAngleList.append(trueFaceAngle)

plt.figure()
plt.plot(list(range(index1,index2)),attackAngle)
plt.plot(list(range(index1,index2)),trueAttackAngleList)
plt.title('Attack Angle')
plt.figure()
plt.plot(list(range(index1,index2)),clubPath)
plt.plot(list(range(index1,index2)),trueClubPathList)
plt.title('Club Path')
plt.figure()
plt.plot(list(range(index1,index2)),faceToPath)
plt.plot(list(range(index1,index2)),trueFaceToPathList)
plt.title('Face To Path')
plt.figure()
plt.plot(list(range(index1,index2)),faceAngle)
plt.plot(list(range(index1,index2)),trueFaceAngleList)
plt.title('Face Angle')

plt.figure()
plt.plot(list(range(len(t))),swing.clubheadSpeed)
plt.plot(list(range(len(t))),trueClubSpeedList)
plt.title('Clubhead Speed')
plt.plot(impact,y)
# plt.show()

rawAcc = swing.sensor.rawAcc
rawGyro = swing.sensor.rawGyro
Acc = swing.sensor.acc
Gyro = swing.sensor.gyro
AccXComp = []
AccYComp = []
AccZComp = []
GyroXComp = []
GyroYComp = []
GyroZComp = []
rawAccX = []
rawAccY = []
rawAccZ = []
rawGyroX = []
rawGyroY = []
rawGyroZ = []
# rawAccX, rawAccY, rawAccZ, rawGyroX, rawGyroY, rawGyroZ = SensorToBody(rawAcc,rawGyro)
# t = [0]
for ii in range(len(rawAcc)):
    rawAccX.append(rawAcc[ii].x)
    rawAccY.append(rawAcc[ii].y)
    rawAccZ.append(rawAcc[ii].z)
    rawGyroX.append(rawGyro[ii].x)
    rawGyroY.append(rawGyro[ii].y)
    rawGyroZ.append(rawGyro[ii].z)
    AccXComp.append(Acc[ii].x)
    AccYComp.append(Acc[ii].y)
    AccZComp.append(Acc[ii].z)
    GyroXComp.append(Gyro[ii].x)
    GyroYComp.append(Gyro[ii].y)
    GyroZComp.append(Gyro[ii].z)
#     t.append(t[ii] + 1/FREQUENCY)
# t.pop()

# GyroXComp = ImpactNoiseCompensator(t,rawGyroX,FS = DEG2RAD*GYRO_FS)
# GyroYComp = ImpactNoiseCompensator(t,rawGyroY,FS = DEG2RAD*GYRO_FS)
# GyroZComp = ImpactNoiseCompensator(t,rawGyroZ,FS = DEG2RAD*GYRO_FS)
# AccXComp = ImpactNoiseCompensator(t,rawAccX,ACC_FS)
# AccYComp = ImpactNoiseCompensator(t,rawAccY,ACC_FS)
# AccZComp = ImpactNoiseCompensator(t,rawAccZ,ACC_FS,satComp = True)
#
# swing = Swing(club)


plt.figure()
plt.plot(list(range(len(t))),rawAccX,'b')
plt.plot(list(range(len(t))),AccXComp,'k')
plt.title('Raw Acc X')
plt.figure()
plt.plot(list(range(len(t))),rawAccY,'b')
plt.plot(list(range(len(t))),AccYComp,'k')
plt.title('Raw Acc Y')
plt.figure()
plt.plot(list(range(len(t))),rawAccZ,'b')
plt.plot(list(range(len(t))),AccZComp,'k')
plt.title('Raw Acc Z')
plt.figure()
plt.plot(list(range(len(t))),rawGyroX,'b')
plt.plot(list(range(len(t))),GyroXComp,'k')
plt.title('Raw Gyro X')
plt.figure()
plt.plot(list(range(len(t))),rawGyroY,'b')
plt.plot(list(range(len(t))),GyroYComp,'k')
plt.title('Raw Gyro Y')
plt.figure()
plt.plot(list(range(len(t))),rawGyroZ,'b')
plt.plot(list(range(len(t))),GyroZComp,'k')
plt.title('Raw Gyro Z')
plt.show()
