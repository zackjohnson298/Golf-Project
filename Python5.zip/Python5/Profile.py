from GolfBag import *
from Swing import *
from Session import *
import os

class Profile():
    def __init__(self,name):
        self.golfBag = GolfBag()
        self.session = Session()
        self.userData = []
        self.name = name
        self.profilePath = ''
        self.golfBagPath = ''
        self.sessionsPath = ''

    def Initialize(self):
        relPath = os.path.join('Profiles',self.name)
        self.profilePath = os.path.abspath(relPath)
        if not os.path.exists(self.profilePath):
            userInput = input('Your Profile does not exist, would you like to create one? (y/n): ')
            while userInput.lower() != 'y' and userInput.lower() != 'n':
                userInput = input('Invalid input (y/n): ')
            if userInput.lower() == 'n':
                return
            os.makedirs(self.profilePath)
            self.golfBagPath = os.path.join(self.profilePath,'GolfBag')
            self.sessionsPath = os.path.join(self.profilePath,'Sessions')
            os.makedirs(self.golfBagPath)
            os.makedirs(self.sessionsPath)
            self.golfBag.CreateBag()
            self.golfBag.SaveBag(self.golfBagPath)
        else:
            self.golfBagPath = os.path.join(self.profilePath,'GolfBag')
            self.sessionsPath = os.path.join(self.profilePath,'Sessions')
            self.golfBag.LoadBag(self.golfBagPath)

    #Error Check
    def BeginNewSession(self):
        self.session.Create(self.sessionsPath)
        self.session.Begin(self.golfBag.clubs)

    def LoadSavedSession(self):
        while not self.session.Resume(self.sessionsPath):
            print('Session does not exist')
            print('Please select an option:')
            print('  t - Try again')
            print('  r - Return to Main Menu')
            userInput = input('Input: ')
            if userInput == 't':
                continue
            else:
                return
        self.session.Begin(self.golfBag.clubs)
        # userInput = input('Would you like to continue an old Session? (y/n): ')
        # if userInput == 'y':
        #     while not self.session.Resume():
        #         print('That session does not exist')
    #
    # def Load(self):
    #
    # def Create(self):
