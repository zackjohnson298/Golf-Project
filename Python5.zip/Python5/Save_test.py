from Swing import *
from Club import *
from GPF_Constants import *
import matplotlib.pyplot as plt

newClub = Club('7iron',1,20,30,5)
jj = 0
while 1:
    print('Choose an option :')
    print(' n = record new swing')
    print(' c = change club (current = ' + newClub.type + ')')
    print(' e = end session')

    userInput = input('Input: ')
    if userInput == 'c':
        clubType = input('Enter new clubtype: ')
        length = input('Enter length: ')
        newClub = Club(clubType,1,20,30,5)
        continue
    elif userInput == 'n':
        newSwing = Swing(newClub)
        newSwing.GetSensorData()
    elif userInput == 'e':
        choice = input('Are you sure?(y/n): ')
        if choice == 'y':
            break
        continue
    else:
        print('Invalid input')
        continue

    t = [0]
    for ii in range(1,len(newSwing.sensor.gyroMag)):
        t.append(t[ii-1] + 1/FREQUENCY)
    plt.plot(t,newSwing.sensor.gyroMag)
    plt.xlabel('Time t [s]')
    plt.ylabel('Gyro Magnitude [rad/s]')
    plt.show()

    userInput = input('Would you like to save this swing?(y/n): ')
    if userInput == 'y':
        filename = 'Swings/' + str(jj+1) + '_(' + newClub.type + ').txt'
        newSwing.Save(filename)
        jj += 1
