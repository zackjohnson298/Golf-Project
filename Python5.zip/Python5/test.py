import numpy as np
from math import *
import matplotlib.pyplot as plt

def CurveFit(xdata,ydata):
    m = len(xdata)
    A = np.zeros((m,m))
    b = np.zeros((m,1))
    for ii in range(m,0,-1):
        b[ii-1] = ydata[ii-1]
        for jj in range(m):
            A[jj][m-ii] = xdata[jj]**(ii-1)

    C = np.linalg.inv(A)@b
    return C

xdata = [1,2,3,4]
ydata = [3,1,3,1]
C = CurveFit(xdata,ydata)
x = []
y = []
for ii in range(0,5000):
    x.append(ii/1000)
    y.append(C[0]*(x[ii]**3) + C[1]*(x[ii]**2) + C[2]*(x[ii]) + C[3])

plt.figure()
plt.plot(x,y,'b')
plt.plot(xdata,ydata,'rx')
plt.show()
