from VectorMath import *
from GPF_Constants import *
from math import *
from scipy.fft import fft, ifft
from scipy.signal import butter, lfilter, filtfilt
import numpy as np

def ButterFilter(data,t,cutoff,order,btype):
    def butter_lowpass(cutoff, fs, order,btype):
        nyq = 0.5 * fs
        normal_cutoff = cutoff / nyq
        b, a = butter(order, normal_cutoff, btype, analog=False)
        return b, a

    def butter_lowpass_filter(data, cutoff, fs, order,btype):
        b, a = butter_lowpass(cutoff, fs, order, btype)
        y = filtfilt(b, a, data)
        return y

    N = len(t)
    fs = N/t[-1]

    return butter_lowpass_filter(np.array(data), cutoff, fs, order,btype)

def SensorToBody(aS,gS):
    accOutX = []
    accOutY = []
    accOutZ = []
    gyroOutX = []
    gyroOutY = []
    gyroOutZ = []
    qS_B = Quaternion(1/sqrt(2),0,-1/sqrt(2),0)
    for ii in range(len(aS)):
        aB = QuatRot(qS_B,aS[ii])
        gB = QuatRot(qS_B,gS[ii])
        accOutX.append(aB.x)
        accOutY.append(aB.y)
        accOutZ.append(aB.z)
        gyroOutX.append(gB.x)
        gyroOutY.append(gB.y)
        gyroOutZ.append(gB.z)
    return accOutX, accOutY, accOutZ, gyroOutX, gyroOutY, gyroOutZ

def CurveFit(xdata,ydata):
    m = len(xdata)
    A = np.zeros((m,m))
    b = np.zeros((m,1))
    for ii in range(m,0,-1):
        b[ii-1] = ydata[ii-1]
        for jj in range(m):
            A[jj][m-ii] = xdata[jj]**(ii-1)

    C = np.linalg.inv(A)@b
    return C

def SaturationCompensator(t,ydata,FS,satThresh):
    jj = 0
    for ii in range(len(t)):
        saturatedCount = 0
        if abs(ydata[ii]) >= (FS - .1):
            for jj in range(ii,ii+satThresh):
                if abs(ydata[jj]) >= (ACC_FS - .1):
                    saturatedCount += 1
                else:
                    saturatedCount = 0
                    break
            if saturatedCount == satThresh:
                x2 = int(ii)
                kk = int(ii)
                while abs(ydata[kk]) >= (FS - .1):
                    kk += 1
                x3 = int(kk)
                break

    if saturatedCount == 10:
        x1 = x2 - 10
        x4 = x3 + 10
        y1 = ydata[x1]
        y2 = ydata[x2]
        y3 = ydata[x3]
        y4 = ydata[x4]
        C = CurveFit([x1,x2,x3,x4],[y1,y2,y3,y4])
        for ii in range(x2,x3):
            ydata[ii] = (C[0]*(ii**3) + C[1]*(ii**2) + C[2]*ii + C[3])
    else:
        x4 = 0
    return ydata,x4

def ImpactNoiseCompensator(t,ydata,FS,xPointsSpacing = [50,30,10,10,30,50],filtCutoff = 15,satComp = False,satThresh = 10):
    if satComp:
        ydata,startIndex = SaturationCompensator(t,ydata,FS,satThresh)
    else:
        startIndex = 0

    for ii in range(startIndex,len(ydata)):
        if abs(ydata[ii]) >= (FS - .1):
            impactIndex = ii - 5
            break
    for ii in range(len(ydata)-1,0,-1):
        if abs(ydata[ii]) >= (FS - .1):
            impactEndIndex = ii + 5
            break

    x1 = impactIndex - xPointsSpacing[0]
    x2 = impactIndex - xPointsSpacing[1]
    x3 = impactIndex - xPointsSpacing[2]
    x4 = impactEndIndex + xPointsSpacing[3]
    x5 = impactEndIndex + xPointsSpacing[4]
    x6 = impactEndIndex + xPointsSpacing[5]
    leftData = ydata[:x3]
    rightData = ButterFilter(ydata[x4:],t[x4:],filtCutoff,1,'low')
    y1 = leftData[x1 - 1]
    y2 = leftData[x2 - 1]
    y3 = leftData[x3 - 1]
    y4 = rightData[x4 - impactEndIndex - 1]
    y5 = rightData[x5 - impactEndIndex - 1]
    y6 = rightData[x6 - impactEndIndex - 1]

    C = CurveFit([x1,x2,x3,x4,x5,x6],[y1,y2,y3,y4,y5,y6])
    fitData = []
    for ii in range(x1,x6):
        fitData.append(C[0]*(ii**5) + C[1]*(ii**4) + C[2]*(ii**3) + C[3]*(ii**2) + C[4]*ii + C[5])

    compData = list(leftData)
    for ii in range(x3,x6):
        compData.append(fitData[ii - x1])
    for ii in range(x6 - x4,len(rightData)):
        compData.append(rightData[ii])

    return compData
