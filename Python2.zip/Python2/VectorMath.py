from math import *
import numpy as np

class Quaternion():
    def __init__(self, q0 = 1, q1 = 0, q2 = 0, q3 = 0):
        self.q0 = q0
        self.q1 = q1
        self.q2 = q2
        self.q3 = q3

    def Normalize(self):
        q0 = self.q0
        q1 = self.q1
        q2 = self.q2
        q3 = self.q3
        mag = sqrt(q0**2 + q1**2 + q2**2 + q3**2)
        self.q0 = q0 / mag
        self.q1 = q1 / mag
        self.q2 = q2 / mag
        self.q3 = q3 / mag

class Vector():
    def __init__(self, vx = 0, vy = 0, vz = 0):
        self.vx = vx
        self.vy = vy
        self.vz = vz

    def Normalize(self):
        mag = Norm(self)
        self.vx /= mag
        self.vy /= mag
        self.vz /= mag

def Cross(a,b):
    ax = a.vx
    ay = a.vy
    az = a.vz
    bx = b.vx
    by = b.vy
    bz = b.vz
    cx = ay*bz - az*by
    cy = az*bx - ax*bz
    cz = ax*by - ay*bx
    c = Vector(cx,cy,cz)
    return c

def Norm(v):
    vx = v.vx
    vy = v.vy
    vz = v.vz
    mag = sqrt(vx**2 + vy**2 + vz**2)
    return mag

def Dot(a,b):
    return (a.vx*b.vx + a.vy*b.vy + a.vz*b.vz)

def VectorNegate(v):
    vMinus = Vector(-v.vx,-v.vy,-v.vz)
    return vMinus

def VectorSubtract(a,b):
    bMinus = VectorNegate(b)
    c = VectorAdd(a,bMinus)
    return c

def VectorAdd(a,b):
    cx = a.vx + b.vx
    cy = a.vy + b.vz
    cz = a.vz + b.vy
    c = Vector(cx,cy,cz)
    return c

def QuatProd(a,b):
    # a and b are Quaternion objects
    a0 = a.q0
    a1 = a.q1
    a2 = a.q2
    a3 = a.q3

    b0 = b.q0
    b1 = b.q1
    b2 = b.q2
    b3 = b.q3

    c0 = a0*b0 - a1*b1 - a2*b2 - a3*b3
    c1 = a0*b1 + a1*b0 + a2*b3 - a3*b2
    c2 = a0*b2 - a1*b3 + a2*b0 + a3*b1
    c3 = a0*b3 + a1*b2 - a2*b1 + a3*b0

    c = Quaternion(c0,c1,c2,c3)
    return c

def QuatConj(q):
    q0 = q.q0
    q1 = q.q1
    q2 = q.q2
    q3 = q.q3
    qConj = Quaternion(q0,-q1,-q2,-q3)
    return qConj

def Vec2Quat(v):
    vx = v.vx
    vy = v.vy
    vz = v.vz
    q = Quaternion(0,vx,vy,vz)
    return q

def Quat2Vec(q):
    q1 = q.q1
    q2 = q.q2
    q3 = q.q3
    v = Vector(q1,q2,q3)
    return v

def ScaleQuat(q,k):
    q0 = k*q.q0
    q1 = k*q.q1
    q2 = k*q.q2
    q3 = k*q.q3
    return Quaternion(q0,q1,q2,q3)

def ScaleVector(v,k):
    vx = k*v.vx
    vy = k*v.vy
    vz = k*v.vz
    return Vector(vx,vy,vz)


def QuatRot(q,v):
    qv = Vec2Quat(v)
    qConj = QuatConj(q)
    vRot = Quat2Vec(QuatProd(QuatProd(q,qv),qConj))
    return vRot

def Quat2List(q):
    q0 = q.q0
    q1 = q.q1
    q2 = q.q2
    q3 = q.q3
    qList = list([q0,q1,q2,q3])
    return qList

def Vec2List(v):
    vx = v.vx
    vy = v.vy
    vz = v.vz
    vList = list([vx,vy,vz])
    return vList

def AngularVelocity2Quat(w,dt):
    # w is Vector type
    wx = w.vx
    wy = w.vy
    wz = w.vz

    wMag = sqrt(wx**2 + wy**2 + wz**2)
    half_dt_wMag = 0.5*dt*wMag
    q0 = cos(half_dt_wMag)
    q1 = sin(half_dt_wMag) * wx / wMag
    q2 = sin(half_dt_wMag) * wy / wMag
    q3 = sin(half_dt_wMag) * wz / wMag

    q = Quaternion(q0,q1,q2,q3)
    return q
