import serial
import time
from VectorMath import *
from math import *
from scipy.fft import fft
from scipy.signal import butter, lfilter, filtfilt
from statsmodels.nonparametric.smoothers_lowess import lowess
import keyboard
import matplotlib.pyplot as plt

class Sensor():
    def __init__(self):
        self.rawData = []
        self.qs = []
        self.qc = []
        self.w = []
        self.accS = []
        self.accW = []
        self.v = []
        self.Vc = []
        self.VcMag = []
        self.t = []
        self.q0 = Quaternion()
        self.wOffset = Vector()

    def GetData(self,port = 'COM10',baudrate = 115200,BUFFER_LEN = 24,trimTime = 1,calTime = -1,aThresh = 1.001,L = 1):
        self.GetRawData(port,baudrate,BUFFER_LEN)
        self.ConvertRawData()
        self.TrimData(trimTime)
        self.Calibrate(calTime)
        self.GetQuatfromRates()
        self.GetWorldAcc()
        self.GetVelZUPT()
        self.GetClubheadSpeed(L)

    def GetWorldAcc(self):
        for ii in range(0,len(self.t)):
            self.accW.append(QuatRot(self.qs[ii],self.accS[ii]))

    def TrimData(self,trimTime):
        count = 0
        for t in self.t:
            if t <= trimTime:
                count += 1
            else:
                break
        self.qs = self.qs[count:]
        self.w = self.w[count:]
        self.accS = self.accS[count:]
        self.t = self.t[count:]
        for ii in range(0,len(self.t)):
            self.t[ii] -= trimTime

    def GetRawData(self,port,baudrate,BUFFER_LEN):
        # set up the serial line
        ser = serial.Serial(port, baudrate, timeout = 1)
        time.sleep(2)
        ser.write(b'r')

        #Remove initialization instructions from Serial Port
        for i in range(0,16):
            b = ser.readline()         # read a byte string

        # Read and record the data
        rawData = []
        ii = 0
        while True:
            if keyboard.is_pressed('q'):
                print('Keyboard Interupt')
                break
            else:
                b = ser.readline()
                if len(b) == BUFFER_LEN:
                    if ii == 0:
                        start = time.time()
                        t = [0]
                    else:
                        t = [time.time() - start]
                    rawData.append(list(b) + list(t))
                    ii = ii + 1

        ser.close()
        self.rawData = rawData

    def ConvertRawData(self):
        dataRow = [0,0,0,0,0,0,0,0,0,0,0]
        C = 30/2.6
        deg2rad = C*pi/180
        for ii in range(0,len(self.rawData)):
            b = self.rawData[ii]
            # Quaternions
            dataRow[0] = (b[2] << 8 | b[3])/16384.0
            dataRow[1] = (b[4] << 8 | b[5])/16384.0
            dataRow[2] = (b[6] << 8 | b[7])/16384.0
            dataRow[3] = (b[8] << 8 | b[9])/16384.0
            for jj in range(0,4):
                if dataRow[jj] >= 2:
                    dataRow[jj] = dataRow[jj] - 4
            # Gyro [rad/s]
            dataRow[4] = deg2rad*(b[10] << 8 | b[11])/8.192
            dataRow[5] = deg2rad*(b[12] << 8 | b[13])/8.192
            dataRow[6] = deg2rad*(b[14] << 8 | b[15])/8.192
            for jj in range(4,7):
                if dataRow[jj] >= deg2rad*4000:
                    dataRow[jj] = dataRow[jj] - deg2rad*8000
            # Accelerometer [G]
            dataRow[7] = (b[16] << 8 | b[17])/8192
            dataRow[8] = (b[18] << 8 | b[19])/8192
            dataRow[9] = (b[20] << 8 | b[21])/8192
            for jj in range(7,10):
                if dataRow[jj] >= 4:
                    dataRow[jj] = dataRow[jj] - 8
            # Time [s]
            dataRow[10] = b[24]
            qs = list(dataRow[0:4])
            w = list(dataRow[4:7])
            accS = list(dataRow[7:10])
            q = Quaternion(qs[0],qs[1],qs[2],qs[3])
            q.Normalize()
            self.qs.append(q)
            self.w.append(Vector(w[0],w[1],w[2]))
            self.accS.append(Vector(accS[0],accS[1],accS[2]))
            self.t.append(dataRow[10])

    def Calibrate(self,calTime):
        count = 0
        wxSum = 0
        wySum = 0
        wzSum = 0
        rxSum = 0
        rySum = 0
        rzSum = 0
        tMax = self.t[-1]
        if calTime < 0:
            calTime = tMax

        for ii in range(0,len(self.t)):
            if self.t[ii] <= calTime:
                w = self.w[ii]
                r = self.accS[ii]
                wxSum += w.vx
                wySum += w.vy
                wzSum += w.vz
                rxSum += r.vx
                rySum += r.vy
                rzSum += r.vz
                count += 1
            else:
                break
        self.wOffset.vx = wxSum / count
        self.wOffset.vy = wySum / count
        self.wOffset.vz = wzSum / count

        rx = rxSum / count
        ry = rxSum / count
        rz = rxSum / count
        r = Vector(rx,ry,rz)
        r.Normalize()
        yS = Vector(0,1,0)
        zS = Vector(0,0,1)
        xW = Cross(yS,r)
        xW.Normalize()
        theta1 = acos(Dot(yS,r)) - pi/2
        q1_0 = cos(theta1/2)
        q1_1 = xW.vx*sin(theta1/2)
        q1_2 = xW.vy*sin(theta1/2)
        q1_3 = xW.vz*sin(theta1/2)
        q1 = Quaternion(q1_0, q1_1, q1_2, q1_3)
        r2 = QuatRot(q1,r)
        y2 = QuatRot(q1,yS)
        z2 = QuatRot(q1,zS)
        theta2 = acos(Dot(z2,r))
        q2_0 = cos(theta2/2)
        q2_1 = y2.vx*sin(theta2/2)
        q2_2 = y2.vy*sin(theta2/2)
        q2_3 = y2.vz*sin(theta2/2)
        q2 = Quaternion(q2_0, q2_1, q2_2, q2_3)
        self.q0 = QuatProd(q1,q2)

    def GetQuatfromRates(self):
        self.q0 = Quaternion(1,0,0,0)
        self.qc.append(self.q0)
        gyroOffset = self.wOffset
        for ii in range(1,len(self.t)):
            dt = self.t[ii] - self.t[ii-1]
            w = VectorSubtract(self.w[ii],gyroOffset)
            delta_q = AngularVelocity2Quat(w,dt)
            self.qc.append(QuatProd(self.qc[ii-1],delta_q))

    def GetVelZUPT(self, gravity = 9.81, thresh=0.035, lowCutoff = 10, highCutoff = 0.001, showPlots = False):
        aMag = []
        stationary = []
        for ii in range(0,len(self.t)):
            a = self.accW[ii]
            aMag.append(sqrt(a.vx**2 + a.vy**2 + a.vz**2))
        aMag = abs(ButterFilter(aMag,self.t,highCutoff,1,'high'))
        aMag = ButterFilter(aMag,self.t,lowCutoff,1,'low')
        for ii in range(0,len(aMag)):
            if abs(aMag[ii]) < thresh:
                stationary.append(1)
            else:
                stationary.append(0)
        # if showPlots:
        #     plt.figure()
        #     plt.plot(self.t,stationary)
        #     plt.plot(self.t,aMag)
        #     plt.title('Acceleration Magnitude')

        xddot = []
        yddot = []
        zddot = []

        for ii in range(0,len(self.t)):
            a = Vec2List(self.accW[ii])
            xddot.append(a[0])
            yddot.append(a[1])
            zddot.append(a[2])

        xddot = ButterFilter(xddot,self.t,highCutoff,1,'high')
        yddot = ButterFilter(yddot,self.t,highCutoff,1,'high')
        zddot = ButterFilter(zddot,self.t,highCutoff,1,'high')

        nonStatPeriods = []
        xdot = [0]
        ydot = [0]
        zdot = [0]
        for ii in range(1,len(self.t)):
            if stationary[ii] == 1:
                xdot.append(0)
                ydot.append(0)
                zdot.append(0)
                if stationary[ii-1] == 0:
                    nonStatPeriods.append(list([startIndex,ii-1]))
            else:
                dt = self.t[ii] - self.t[ii-1]
                xdot.append(gravity*xddot[ii]*dt + xdot[ii-1])
                ydot.append(gravity*yddot[ii]*dt + ydot[ii-1])
                zdot.append(gravity*zddot[ii]*dt + zdot[ii-1])
                if stationary[ii-1] == 1:
                    startIndex = ii-1
        # if showPlots:
            # plt.figure()
            # plt.plot(self.t,self.xdot)
            # plt.plot(self.t,self.ydot)
            # plt.plot(self.t,self.zdot)
            # plt.legend(('xdot','ydot','zdot'))
            # plt.title('Raw Velocities')

        for i in range(0,len(nonStatPeriods)):
            i1 = nonStatPeriods[i][0]
            i2 = nonStatPeriods[i][1]
            N = i2 - i1
            dvx = xdot[i2]-xdot[i1]
            dvy = ydot[i2]-ydot[i1]
            dvz = zdot[i2]-zdot[i1]
            ratex = dvx/N
            ratey = dvy/N
            ratez = dvz/N
            for ii in range(i1,i2+1):
                xdot[ii] -= ratex*(ii - i1)
                ydot[ii] -= ratey*(ii - i1)
                zdot[ii] -= ratez*(ii - i1)

        for ii in range(0,len(self.t)):
            v = Vector(xdot[ii],ydot[ii],zdot[ii])
            self.v.append(v)
        # if showPlots:
            # plt.figure()
            # plt.plot(self.t,self.xdot)
            # plt.plot(self.t,self.ydot)
            # plt.plot(self.t,self.zdot)
            # plt.legend(('xdot','ydot','zdot'))
            # plt.title('Compensated Velocities')
            # plt.show()

    def GetClubheadSpeed(self,L):
        Vc = []
        club = Quaternion(0,0,0,L)
        for ii in range(0,len(self.t)):
            q = self.qc[ii]
            Vs = self.v[ii]
            w = Vec2Quat(VectorSubtract(self.w[ii],self.wOffset))
            Two_qdot = QuatProd(q,w)
            qdot = ScaleQuat(Two_qdot,.5)
            v1 = Quat2Vec(QuatProd(QuatProd(qdot,club),QuatConj(q)))
            v2 = Quat2Vec(QuatProd(QuatProd(q,club),QuatConj(qdot)))
            Vc = VectorAdd(VectorAdd(self.v[ii],v1),v2)
            Vc = ScaleVector(Vc,2.23694)
            self.Vc.append(Vc)
            self.VcMag.append(Norm(Vc))

    def ClearData(self):
        self.rawData = []
        self.qs = []
        self.qc = []
        self.w = []
        self.accS = []
        self.accW = []
        self.t = []

    def PlotQuaternion(self,show = False):
        t = self.t
        q0_S = []
        q0_C = []
        q1_S = []
        q1_C = []
        q2_S = []
        q2_C = []
        q3_S = []
        q3_C = []

        for ii in range(0,len(t)):
            qs = Quat2List(self.qs[ii])
            qc = Quat2List(self.qc[ii])
            q0_S.append(qs[0])
            q0_C.append(qc[0])
            q1_S.append(qs[1])
            q1_C.append(qc[1])
            q2_S.append(qs[2])
            q2_C.append(qc[2])
            q3_S.append(qs[3])
            q3_C.append(qc[3])

        plt.figure()
        plt.suptitle('Quaternion vs. Time')
        plt.subplot(411)
        plt.plot(t,q0_S,t,q0_C)
        plt.subplot(412)
        plt.plot(t,q1_S,t,q1_C)
        plt.subplot(413)
        plt.plot(t,q2_S,t,q2_C)
        plt.subplot(414)
        plt.plot(t,q3_S,t,q3_C)
        if show:
            plt.show()

    def PlotGyro(self,show = False):
        t = self.t
        wx = []
        wy = []
        wz = []

        for ii in range(0,len(t)):
            w = Vec2List(self.w[ii])
            wx.append(w[0])
            wy.append(w[1])
            wz.append(w[2])

        plt.figure()
        plt.suptitle('Angular Velocities vs. Time')
        plt.subplot(311)
        plt.plot(t,wx)
        plt.subplot(312)
        plt.plot(t,wy)
        plt.subplot(313)
        plt.plot(t,wz)
        if show:
            plt.show()

    def PlotWorldAcceleration(self,show = False):
        t = self.t
        ax = []
        ay = []
        az = []

        for ii in range(0,len(t)):
            aW = Vec2List(self.accW[ii])
            ax.append(aW[0])
            ay.append(aW[1])
            az.append(aW[2])

        plt.figure()
        plt.suptitle('World Frame Acceleration vs. Time')
        plt.subplot(311)
        plt.plot(t,ax)
        plt.subplot(312)
        plt.plot(t,ay)
        plt.subplot(313)
        plt.plot(t,az)
        if show:
            plt.show()

    def PlotSensorAcceleration(self,show = False):
        t = self.t
        ax = []
        ay = []
        az = []

        for ii in range(0,len(t)):
            aS = Vec2List(self.accS[ii])
            ax.append(aS[0])
            ay.append(aS[1])
            az.append(aS[2])

        plt.figure()
        plt.suptitle('Sensor Frame Acceleration vs. Time')
        plt.subplot(311)
        plt.plot(t,ax)
        plt.subplot(312)
        plt.plot(t,ay)
        plt.subplot(313)
        plt.plot(t,az)
        if show:
            plt.show()

    def PlotClubSpeed(self,show = False):
        t = self.t
        vx = []
        vy = []
        vz = []

        for ii in range(0,len(t)):
            Vc = Vec2List(self.Vc[ii])
            vx.append(Vc[0])
            vy.append(Vc[1])
            vz.append(Vc[2])

        plt.figure()
        plt.suptitle('Clubhead Speed Components vs. Time')
        plt.subplot(311)
        plt.plot(t,vx)
        plt.subplot(312)
        plt.plot(t,vy)
        plt.subplot(313)
        plt.plot(t,vz)
        plt.figure()
        plt.title('Clubhead Speed Magnitude vs. Time')
        plt.plot(t,self.VcMag)
        if show:
            plt.show()


def ButterFilter(data,t,cutoff,order,btype):
    def butter_lowpass(cutoff, fs, order,btype):
        nyq = 0.5 * fs
        normal_cutoff = cutoff / nyq
        b, a = butter(order, normal_cutoff, btype, analog=False)
        return b, a

    def butter_lowpass_filter(data, cutoff, fs, order,btype):
        b, a = butter_lowpass(cutoff, fs, order, btype)
        y = filtfilt(b, a, data)
        return y

    N = len(t)
    fs = N/t[-1]

    return butter_lowpass_filter(np.array(data), cutoff, fs, order,btype)
