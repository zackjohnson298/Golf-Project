import Sensor
from VectorMath import *

class Club():
    def __init__(self,length,loft,lieAngle):
        self.mpu = Sensor.Sensor()
        self.length = length
        self.loft = loft
        self.lieAngle = lieAngle
        self.HeadVel = []

    def GetNewMotion(self):
        self.mpu.ClearData()
        self.mpu.GetData()

    def GetClubSpeed(self):
        
