import Sensor
import Club

class Swing():
    def __init__(self):
        self.sensor = Sensor.Sensor()
