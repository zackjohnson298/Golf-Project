def ConvertRawData(self):
    dataRow = [0,0,0,0,0,0,0,0,0,0,0]
    C = 30/2.6
    deg2rad = C*pi/180
    for ii in range(0,len(self.rawData)):
        b = self.rawData[ii]
        # Quaternions
        dataRow[0] = (b[2] << 24 | b[3] << 16 | b[4] << 8 | b[5])/1073741824.0
        dataRow[1] = (b[6] << 24 | b[7] << 16 | b[8] << 8 | b[9])/1073741824.0
        dataRow[2] = (b[10] << 24 | b[11] << 16 | b[12] << 8 | b[13])/1073741824.0
        dataRow[3] = (b[14] << 24 | b[15] << 16 | b[16] << 8 | b[17])/1073741824.0
        for jj in range(0,4):
            if dataRow[jj] >= 2:
                dataRow[jj] = dataRow[jj] - 4
        # Gyro [rad/s]
        dataRow[4] = deg2rad*(b[18] << 24 | b[19] << 16 | b[20] << 8 | b[21])/536870.912
        dataRow[5] = deg2rad*(b[22] << 24 | b[23] << 16 | b[24] << 8 | b[25])/536870.912
        dataRow[6] = deg2rad*(b[26] << 24 | b[27] << 16 | b[28] << 8 | b[29])/536870.912
        for jj in range(4,7):
            if dataRow[jj] >= deg2rad*4000:
                dataRow[jj] = dataRow[jj] - deg2rad*8000
        # Accelerometer [G]
        dataRow[7] = (b[30] << 24 | b[31] << 16 | b[32] << 8 | b[33])/536870912.0
        dataRow[8] = (b[34] << 24 | b[35] << 16 | b[36] << 8 | b[37])/536870912.0
        dataRow[9] = (b[38] << 24 | b[39] << 16 | b[40] << 8 | b[41])/536870912.0
        for jj in range(7,10):
            if dataRow[jj] >= 4:
                dataRow[jj] = dataRow[jj] - 8
        # Time [s]
        dataRow[10] = b[44]
        qs = list(dataRow[0:4])
        w = list(dataRow[4:7])
        accS = list(dataRow[7:10])
        q = Quaternion(qs[0],qs[1],qs[2],qs[3])
        q.Normalize()
        self.qs.append(q)
        self.w.append(Vector(w[0],w[1],w[2]))
        self.accS.append(Vector(accS[0],accS[1],accS[2]))
        self.t.append(dataRow[10])
