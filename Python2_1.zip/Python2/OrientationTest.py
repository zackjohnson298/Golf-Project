import Sensor
from VectorMath import *


# BUFFER_LEN = 44
# port = 'COM10'
# baudrate = 115200
mpu = Sensor.Sensor()
mpu.GetData(L = 1)

mpu.PlotQuaternion()
mpu.PlotWorldAcceleration()
# # mpu.PlotGyro(show = True)
# # mpu.PlotClubSpeed(show = True)
mpu.PlotSensorAcceleration()
mpu.PlotVelocity(show = True)
