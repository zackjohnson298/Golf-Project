import Sensor
from VectorMath import *

mpu = Sensor.Sensor()
mpu.GetData(L = 1)

# mpu.PlotQuaternion()
# mpu.PlotWorldAcceleration()
# mpu.PlotGyro()
# # mpu.PlotClubSpeed(show = True)
# mpu.PlotSensorAcceleration()
# mpu.PlotVelocity(show = True)
